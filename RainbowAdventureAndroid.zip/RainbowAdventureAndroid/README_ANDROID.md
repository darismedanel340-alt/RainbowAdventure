# Rainbow Adventure — Android project

This project packages the Rainbow Adventure HTML game inside a native Android WebView.

## Requirements
- Android Studio Meerkat 2024.3.1 or newer
- Android SDK Platform 36
- Android Build Tools 36.x
- JDK supported by your Android Studio/AGP setup

## Open and run
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Install Android SDK 36 if prompted.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run.

## Google Play build
For a Play Store release, use Android Studio's:
Build > Generate Signed App Bundle / APK
and choose Android App Bundle.

Before public release, complete Play Console testing, store listing, privacy/data disclosures, and the required child-directed/Families declarations.

The package/application ID is:
com.rainbowadventure.kids

Version:
1.0 (versionCode 1)
